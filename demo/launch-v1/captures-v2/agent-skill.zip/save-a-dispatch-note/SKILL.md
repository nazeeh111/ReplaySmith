---
name: save-a-dispatch-note
description: "Replay the Save a dispatch note browser workflow with explicit inputs, origin restrictions, and outcome verification. Use when the user requests this recorded task."
---

# Save a dispatch note

Run the recorded workflow only for a user-authorized task. Review [workflow.json](workflow.json) before execution.

## Setup

From this skill directory, use a local Node.js 22+ environment:

```sh
npm install
npx playwright install chromium
```

## Run

```sh
node scripts/run.mjs --inputs '{}'
```

Pass input values as a JSON object through `--inputs`. For private values, use `--inputs-stdin` to read JSON from standard input instead of exposing it in process arguments. Required inputs without defaults must be supplied. Do not store secrets in this skill or commit run artifacts containing private data.

Consequential actions require separate user authorization and `--allow-sensitive`. They use exact recorded selectors and never semantic recovery. Stop if execution abstains or an assertion fails; inspect the target before editing the workflow. Do not weaken safeguards to force completion.

## Verify

Success requires `status: passed`. A verified outcome additionally requires `verified: true`; a run without trailing outcome assertions is not verified. Inspect the per-step report, including candidate scores when recovery was attempted.

## Inputs

- `dispatch_note`: has a stored default
